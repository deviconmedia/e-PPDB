<?php $__env->startSection('title', 'Staff'); ?>

<?php $__env->startSection('page-title', 'Staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="ibox">
    <div class="ibox-head d-flex">
        <div class="ibox-title">Data Staff</div>
        <button class="btn btn-primary" data-toggle="modal" data-target="#newStaffModal"><i class="bi bi-plus-circle-fill"></i> Add new staff</button>
    </div>
    <div class="ibox-body">
        <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Aksi</th>
                    <th>Nama Lengkap</th>
                    <th>Email</th>
                    <th>Tgl Gabung</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <tr>
                    <td>
                        <a href="<?php echo e(route('admin.staff.show', $item->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                        <a href="#" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                    </td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e(date('d F Y, H:i:s', strtotime($item->created_at))); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div> 
<?php elseif($message = Session::get('error')): ?>
<div class="alert alert-danger" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <!-- Modal -->
    <div class="modal fade" id="newStaffModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add New Staff</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('admin.staff.store')); ?>" method="POST" id="newStaffForm">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama">Name <small class="text-danger">*</small></label>
                    <input type="text" id="nama" name="nama" class="form-control" placeholder="Name" autocomplete="off">
                </div>
                <div class="form-group">
                    <label for="email">Email Address <small class="text-danger">*</small></label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Email Address" autocomplete="off">
                </div>
                <div class="form-group">
                    <label for="password">Password <small class="text-danger">*</small></label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="Password">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script type="text/javascript">
    $(function() {
        $('#newStaffForm').validate({
            errorClass: "help-block",
            rules: {
                nama: {
                    required: true,
                },
                email: {
                    required: true,
                    email: true
                },
                password: {
                    required: true
                }
            },
            highlight: function(e) {
                $(e).closest(".form-group").addClass("has-error")
            },
            unhighlight: function(e) {
                $(e).closest(".form-group").removeClass("has-error")
            },
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/admin/staff.blade.php ENDPATH**/ ?>