<?php $__env->startSection('title', 'Pembayaran'); ?>

<?php $__env->startSection('page-title', 'Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="ibox">
    <div class="ibox-head">
        <div class="ibox-title">Daftar Tagihan</div>
    </div>
    <div class="ibox-body">
        <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Aksi</th>
                    <th>Nama Lengkap</th>
                    <th>NISN</th>
                    <th>TTL</th>
                    <th>Jenis Kelamin</th>
                    <th>Agama</th>
                    <th>No. Hp</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
               
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/siswa/pembayaran/index.blade.php ENDPATH**/ ?>