

<?php $__env->startSection('title', 'Website Setting'); ?>

<?php $__env->startSection('page-title', 'Website Setting'); ?>

<?php $__env->startSection('content'); ?>
<nav>
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
      <button class="nav-link active" id="nav-home-tab" data-toggle="tab" data-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true"><i class="bi bi-buildings-fill"></i> Company</button>
      <button class="nav-link" id="nav-sliders-tab" data-toggle="tab" data-target="#nav-sliders" type="button" role="tab" aria-controls="nav-profile" aria-selected="false"><i class="bi bi-sliders"></i> Sliders</button>
      <button class="nav-link" id="nav-contact-tab" data-toggle="tab" data-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false"><i class="bi bi-telephone-fill"></i> Contact</button>
    </div>
  </nav>
  <div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
      <div class="col-md-12">
        <form action="<?php echo e(route('website.setting.company')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <div class="form-group row">
              <label for="company_name" class="col-sm-2 col-form-label">Company Name</label>
              <div class="col-sm-10">
                <input type="text" class="form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="company_name" name="company_name" value="<?php echo e($web->company_name); ?>" autofocus>
                <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row">
              <label for="logo" class="col-sm-2 col-form-label">Logo</label>
              <div class="col-sm-10">
                <input type="file" class="form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="logo" name="logo">
                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row">
              <label for="address" class="col-sm-2 col-form-label">Address</label>
              <div class="col-sm-10">
                <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" name="address" value="<?php echo e($web->address); ?>">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </form>
      </div>
    </div>
    <div class="tab-pane fade" id="nav-sliders" role="tabpanel" aria-labelledby="nav-sliders-tab">
        <div class="row">
            <div class="col-md-8">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Desc</th>
                            <th>Button Link</th>
                            <th>Button Text</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                      <tr>
                        <td class="d-flex">
                          <form action="<?php echo e(route('website.sliders.disable', $slider->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button class="btn btn-sm btn-secondary mr-1"  data-toggle="tooltip" data-placement="right" title="Disable"><i class="bi bi-info-circle"></i></button>
                          </form>
                          <form action="<?php echo e(route('website.sliders.destroy', $slider->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-sm btn-danger" data-toggle="tooltip" data-placement="right" title="Delete"><i class="bi bi-trash"></i></button>
                          </form>
                        </td>
                        <td><img src="<?php echo e(asset('uploads/frontend/' . $slider->image)); ?>" alt="sliders" width="80"></td>
                        <td><?php echo e($slider->title); ?></td>
                        <td><?php echo e($slider->description); ?></td>
                        <td><?php echo e($slider->button_link); ?></td>
                        <td><?php echo e($slider->button_text); ?></td>
                        <td>
                          <?php if($slider->is_active == 1): ?>
                            <span class="badge badge-success">Active</span>
                          <?php else: ?>
                            <span class="badge badge-danger">Disable</span>
                          <?php endif; ?>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4">
               <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('website.setting.sliders')); ?>" method="POST" enctype="multipart/form-data">
                          <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="image">Image <small class="text-danger">*</small></label>
                                <input type="file" name="image" id="image" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="title">Title <small class="text-danger">*</small></label>
                                <input type="text" name="title" id="title" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="description">Description <small class="text-danger">*</small></label>
                               <textarea name="description" id="description" cols="30" rows="4" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                              <label for="button_link">Button Link <small class="text-danger">*</small></label>
                              <input type="text" id="button_link" name="button_link" class="form-control">
                          </div>
                          <div class="form-group">
                            <label for="button_text">Button Text <small class="text-danger">*</small></label>
                            <input type="text" id="button_text" name="button_text" class="form-control">
                          </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
               </div>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('website.setting.update', $web->id)); ?>" method="POST">
                   <?php echo csrf_field(); ?>
                   <?php echo method_field('put'); ?>
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="phonenumber">Telepon</label>
                        <input type="text" class="form-control" id="phonenumber" name="phonenumber">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="email">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email">
                      </div>
                    </div>
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="city">City</label>
                        <input type="text" class="form-control" id="city" name="city">
                      </div>
                      <div class="form-group col-md-4">
                        <label for="state">State</label>
                        <input type="text" id="state" name="state" class="form-control">
                      </div>
                      <div class="form-group col-md-2">
                        <label for="zip">Zip</label>
                        <input type="text" class="form-control" id="zip" name="zip">
                      </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                          <label for="website">Website</label>
                          <input type="text" class="form-control" id="website" name="website">
                        </div>
                        <div class="form-group col-md-3">
                          <label for="facebook">Facebook</label>
                          <input type="text" class="form-control" id="facebook" name="facebook">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="instagram">Instagram</label>
                            <input type="text" class="form-control" id="instagram" name="instagram">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="linkedin">Linkedin</label>
                            <input type="text" class="form-control" id="linkedin" name="linkedin">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                  </form>
            </div>
        </div>
    </div>
  </div>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div> 
<?php elseif($message = Session::get('error')): ?>
<div class="alert alert-danger" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\efron\Workspace\Iconmedia\ppdb\resources\views/backend/admin/setting/index.blade.php ENDPATH**/ ?>