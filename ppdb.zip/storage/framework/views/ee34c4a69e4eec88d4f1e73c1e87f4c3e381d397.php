<?php $__env->startSection('title', 'Detail Pendaftaran'); ?>

<?php $__env->startSection('page-title', 'Detail Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="ibox">
        <div class="ibox-body">
                <table class="table table-bordered">
                    <tr>
                        <th>No Pendaftaran</th>
                        <td><?php echo e($pendaftaran->no_pendaftaran); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Lengkap</th>
                        <td><?php echo e($pendaftaran->nama_lengkap); ?></td>
                    </tr>
                    <tr>
                        <th>NISN</th>
                        <td><?php echo e($pendaftaran->nisn); ?></td>
                    <tr>
                    <tr>
                        <th>NIK</th>
                        <td><?php echo e($pendaftaran->nik); ?></td>
                    </tr>
                    <th>Tempat, Tanggal Lahir</th>
                    <td>
                        <?php echo e($pendaftaran->tempat_lahir); ?>, <?php echo e($pendaftaran->tanggal_lahir); ?>

                    </td>
                    </tr>
                    <tr>
                        <th>Jenis Kelamin</th>
                        <td><?php echo e($pendaftaran->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                        <th>Agama</th>
                        <td><?php echo e($pendaftaran->agama); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Ibu Kandung</th>
                        <td><?php echo e($pendaftaran->nm_ibu_kandung); ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td><?php echo e($pendaftaran->alamat); ?></td>
                    </tr>
                    <tr>
                        <th>Asal Sekolah</th>
                        <td><?php echo e($pendaftaran->sekolah_asal); ?></td>
                    </tr>
                    <tr>
                        <th>No. HP</th>
                        <td><?php echo e($pendaftaran->no_hp); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($pendaftaran->email); ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            <?php if($pendaftaran->status_id == 1): ?>
                                <span class="badge badge-warning">
                                    <?php echo e($pendaftaran->status_pendaftaran->status); ?>

                                </span>
                            <?php elseif($pendaftaran->status_id == 2): ?>
                                <span class="badge badge-success">
                                    <?php echo e($pendaftaran->status_pendaftaran->status); ?>

                                </span>
                            <?php elseif($pendaftaran->status_id == 3): ?>
                                <span class="badge badge-danger">
                                    <?php echo e($pendaftaran->status_pendaftaran->status); ?>

                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <div class="action-btn d-flex justify-content-center my-4">
                    <a href="<?php echo e(route('admin.pendaftaran.index')); ?>" class="btn btn-primary">
                        <i class="fa fa-arrow-left"></i> Kembali
                    </a>
                    <?php if($pendaftaran->status_id == 1): ?>
                        <form action="<?php echo e(route('admin.pendaftaran.accepted', $pendaftaran->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="status_id" value="2">
                            <button type="submit" class="btn btn-success ml-2" onclick="return confirm('Anda yakin menerima peserta ini? klik BATAL jika anda tidak yakin!')">
                                <i class="fa fa-check"></i> Terima
                            </button>
                        </form>
                        <form action="<?php echo e(route('admin.pendaftaran.rejected', $pendaftaran->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="status_id" value="3">
                            <button type="submit" class="btn btn-danger ml-2" onclick="return confirm('Anda yakin menolak peserta ini? klik BATAL jika anda tidak yakin!')">
                                <i class="fa fa-times"></i> Tolak
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
        </div>
    </div>

    
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" role="alert">
            <div class="alert-body">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="close" data-dismiss="alert">×</button>
            </div>
        </div> 
    <?php elseif($message = Session::get('error')): ?>
        <div class="alert alert-danger" role="alert">
            <div class="alert-body">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="close" data-dismiss="alert">×</button>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/admin/show_pendaftaran.blade.php ENDPATH**/ ?>