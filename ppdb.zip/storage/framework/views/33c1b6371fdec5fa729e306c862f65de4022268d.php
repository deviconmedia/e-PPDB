<footer class="page-footer">
    <div class="font-13"><?=date('Y') ?> © <b>Iconmedia</b> - All rights reserved.</div>
    <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer><?php /**PATH C:\Users\efron\Workspace\Iconmedia\ppdb\resources\views/layouts/backend/footer.blade.php ENDPATH**/ ?>