<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('page-title', 'Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body text-center">
            <img src="<?php echo e(asset('backend/img/success.gif')); ?>" alt="success">
            <h1 class="text-center">Pendaftaran Berhasil</h1>
            <p>Selamat! <?php echo e(Auth::user()->name); ?>, data anda berhasil terkirim. Silahkan cek status pendaftaran di halaman <span class="font-weight-bold">Riwayat Pendaftaran</span> </p>
            <a href="<?php echo e(route('guest.pendaftaran.riwayat')); ?>" class="btn btn-success">Cek status pendaftaran</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/guest/pendaftaran/success.blade.php ENDPATH**/ ?>