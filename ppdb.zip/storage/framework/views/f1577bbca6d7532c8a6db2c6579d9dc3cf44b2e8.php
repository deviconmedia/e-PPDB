<?php $__env->startSection('title', 'Periode'); ?>

<?php $__env->startSection('page-title', 'Periode'); ?>

<?php $__env->startSection('content'); ?>
<div class="ibox">
    <div class="ibox-head">
        <div class="ibox-title">Periode</div>
        <div class="ibox-title ml-auto">
            <a href="<?php echo e(route('admin.periode.create')); ?>" class="btn btn-primary"><i class="bi bi-calendar-date"></i> Jadwal Baru</a>
        </div>
    </div>
    <div class="ibox-body">
        <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Periode</th>
                    <th>Tgl Mulai</th>
                    <th>Tgl Selesai</th>
                    <th>Keterangan</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $periodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="#" data-toggle="modal" data-target="#periodeModal<?php echo e($periode->id); ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil-square"></i></a>
                    </td>
                    <td><?php echo e($periode->nama_periode); ?></td>
                    
                    <div class="modal fade" id="periodeModal<?php echo e($periode->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel"><?php echo e($periode->nama_periode); ?></h5>
                              <form action="<?php echo e(route('admin.periode.closed', $periode->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                 <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Anda yakin?')">Tutup Pendaftaran</button>
                              </form>
                            </div>
                            <div class="modal-body">
                              <form action="<?php echo e(route('admin.periode.update', $periode->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                   <div class="form-group">
                                        <label for="nama_periode">Nama Periode</label>
                                        <input type="text" name="nama_periode" id="nama_periode" class="form-control" value="<?php echo e($periode->nama_periode); ?>">
                                   </div>
                                   <div class="form-group">
                                        <label for="tanggal_mulai">Tanggal Mulai</label>
                                        <input type="date" name="tanggal_mulai" id="tanggal_mulai" class="form-control" value="<?php echo e($periode->tanggal_mulai); ?>">
                                   </div>
                                   <div class="form-group">
                                        <label for="tanggal_selesai">Tanggal Selesai</label>
                                        <input type="date" name="tanggal_selesai" id="tanggal_selesai" class="form-control" value="<?php echo e($periode->tanggal_selesai); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="ket">Keterangan</label>
                                        <textarea name="ket" id="ket" cols="30" rows="4" class="form-control"><?php echo e($periode->keterangan); ?></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                    </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    
                    <td><?php echo e(date('d M Y', strtotime($periode->tanggal_mulai))); ?></td>
                    <td><?php echo e(date('d M Y', strtotime($periode->tanggal_selesai))); ?></td>
                    <td><?php echo e($periode->keterangan); ?></td>
                    <td>
                        <?php if($periode->status_periode == 'Buka'): ?>
                            <span class="badge badge-success"><i class="bi bi-check-circle"></i> <?php echo e($periode->status_periode); ?></span>
                        <?php elseif($periode->status_periode == 'Tutup'): ?>
                            <span class="badge badge-danger"><i class="bi bi-x-circle-fill"></i> <?php echo e($periode->status_periode); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div> 
<?php elseif($message = Session::get('error')): ?>
<div class="alert alert-danger" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\efron\Workspace\Iconmedia\ppdb\resources\views/backend/admin/periode/index.blade.php ENDPATH**/ ?>