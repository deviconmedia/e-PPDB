


<style>
    .programs{
        margin-top: 8em;
    }
</style>

<?php $__env->startSection('title'); ?>
    Jurusan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('studi'); ?>
    <div class="programs">
       <div class="container d-flex justify-content-center">
        <h2 class="about-title">Jurusan</h2>
        <p class="about-sub-title">Kami menyediakan beberapa jurusan, pilih Passion kamu!</p>
        <div class="row">
            
            <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeIn">
                    <div class="card shadow-lg" style="width: 28rem;">
                        <img src="<?php echo e(asset('uploads/img/' . $jurusan->thumbnail)); ?>" class="card-img-top" alt="Thumbnail">
                        <div class="card-body">
                        <h4 class="text-center"><?php echo e($jurusan->nama_jurusan); ?></h4>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\efron\Workspace\Iconmedia\ppdb\resources\views/frontend/content/program_studi.blade.php ENDPATH**/ ?>