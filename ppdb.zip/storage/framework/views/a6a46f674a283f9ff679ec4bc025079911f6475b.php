<?php $__env->startSection('title', 'Form Pendaftaran'); ?>

<?php $__env->startSection('page-title', 'Form Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success" role="alert">
        <div class="alert-body">
            <strong><?php echo e($message); ?></strong>
            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
    </div> 
    <?php elseif($message = Session::get('error')): ?>
    <div class="alert alert-danger" role="alert">
        <div class="alert-body">
            <strong><?php echo e($message); ?></strong>
            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
    </div>  
    <?php endif; ?>  

   <form action="<?php echo e(route('student.pendaftaran.store')); ?>" id="pendaftaranForm" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-6">
                <div class="card shadow-lg">
                    <div class="card-header"><i class="bi bi-person"></i> Data Pribadi</div>
                    <div class="card-body">
                            <input type="hidden" name="user_id" value="<?php echo e(Auth()->user()->id); ?>">
                            <div class="form-group">
                                <label for="nama_lengkap">Nama Lengkap <small class="text-danger">*</small></label>
                                <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" placeholder="Nama Lengkap">
                            </div>
                            <label for="">Tempat, Tanggal Lahir <small class="text-danger">*</small></label>
                            <div class="form-row">
                                <div class="col">
                                  <input type="text" name="tempat_lahir" class="form-control" placeholder="Tempat Lahir">
                                </div>
                                <div class="col">
                                  <input type="date" name="tanggal_lahir" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="jenis_kelamin">Jenis Kelamin <small class="text-danger">*</small></label>
                                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                                    <option value="disable selected hidden">--Select--</option>
                                    <option value="Laki-laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="agama">Agama <small class="text-danger">*</small></label>
                                <select name="agama" id="agama" class="form-control">
                                    <option value="disable selected hidden">--Select--</option>
                                    <option value="Islam">Islam</option>
                                    <option value="Kristen">Kristen</option>
                                    <option value="Khatolik">Khatolik</option>
                                    <option value="Hindu">Hindu</option>
                                    <option value="Budha">Budha</option>
                                    <option value="Lainnya">Lainnya</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="nm_ibu_kandung">Nama Ibu Kandung <small class="text-danger">*</small></label>
                                <input type="text" name="nm_ibu_kandung" id="nm_ibu_kandung" class="form-control" placeholder="Nama Ibu Kandung">
                            </div>
                            <div class="form-group">
                                <label for="alamat">Alamat<small class="text-danger">*</small></label>
                                <textarea name="alamat" id="alamat" cols="30" rows="5" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="no_hp">No. HP/WA <small class="text-danger">*</small></label>
                                <input type="number" name="no_hp" id="no_hp" class="form-control" placeholder="No. HP/WA">
                            </div>
                            <div class="form-group">
                                <label for="email">Email Aktif <small class="text-danger">*</small></label>
                                <input type="email" name="email" id="email" class="form-control" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <label for="nik">No. Induk Kependudukan (NIK) <small class="text-danger">*</small></label>
                                <input type="number" name="nik" id="nik" class="form-control" placeholder="NIK">
                            </div>
                            <div class="form-group">
                                <label for="pekerjaan_ortu">Pekerjaan Orangtua <small class="text-danger">*</small></label>
                                <input type="text" name="pekerjaan_ortu" id="pekerjaan_ortu" class="form-control" placeholder="Pekerjaan Orangtua">
                            </div>
                    </div>
                </div>
           </div>
           <div class="col-6">
                <div class="card mb-3 shadow-lg">
                    <div class="card-header"><i class="bi bi-bank"></i> Data Satuan Pendidikan</div>
                    <div class="card-body">
                            <div class="form-group">
                                <label for="nisn">No. Induk Siswa Nasional (NISN) <small class="text-danger">*</small></label>
                                <input type="text" name="nisn" id="nisn" class="form-control" placeholder="No. Induk Siswa Nasional (NISN)">
                            </div>
                            <div class="form-group">
                                <label for="sekolah_asal">Asal Satuan Pendidikan <small class="text-danger">*</small></label>
                                <input type="text" name="sekolah_asal" id="sekolah_asal" class="form-control" placeholder="Asal Satuan Pendidikan">
                            </div>
                            <div class="form-group">
                                <label for="tahun_lulus">Tahun Lulus<small class="text-danger">*</small></label>
                                <input type="number" name="tahun_lulus" id="tahun_lulus" class="form-control" placeholder="Asal Satuan Pendidikan">
                            </div>
                            <div class="form-group">
                                <label for="no_ijazah">No. Ijazah </label>
                                <input type="text" name="no_ijazah" id="no_ijazah" class="form-control" placeholder="No. Ijazah">
                            </div>
                    </div>
                </div>
                <div class="card shadow-lg">
                    <div class="card-header"><i class="bi bi-file-earmark-pdf-fill"></i> Berkas Pendukung</div>
                    <div class="card-body">
                            <div class="form-group">
                                <label for="pas_foto">Foto Pas (Latar belakang merah) <small class="text-danger">*</small></label>
                                <input type="file" name="pas_foto" id="pas_foto" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="fc_ijazah">Foto Copy Ijazah/SKL <small class="text-danger">*</small></label>
                                <input type="file" name="fc_ijazah" id="fc_ijazah" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="fc_kk">Foto Copy Kartu Keluarga (KK)<small class="text-danger">*</small></label>
                                <input type="file" name="fc_kk" id="fc_kk" class="form-control">
                            </div>
                    </div>
                </div>
           </div>
        </div>
        <div class="submit-btn text-right my-3">
            <a href="" class="btn btn-danger" onclick="return confirm('Anda yakin menutup halaman ini?')">Batal</a>
            <button type="submit" class="btn btn-primary" onclick="return confirm('Anda yakin menyimpan data ini?')">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/siswa/form_pendaftaran.blade.php ENDPATH**/ ?>