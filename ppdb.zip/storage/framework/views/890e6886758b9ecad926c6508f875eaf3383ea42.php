<?php $__env->startSection('title', 'Informasi'); ?>

<?php $__env->startSection('page-title', 'Informasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="tombol">
    <?php if(Auth::user()->role == 'admin'): ?>
    <a href="<?php echo e(route('informasi.create')); ?>" class="btn btn-primary mb-5"><i class="bi bi-megaphone"></i> Tambah Informasi</a>
    <?php endif; ?>
</div>
<div class="row">
    <?php if($informasi->isEmpty()): ?>
        <div class="col-12 d-flex justify-content-center">
            <div class="card" style="width: 70%;">
                <div class="card-body text-center">
                    <h5 class="card-title
                    ">Belum ada informasi yang ditampilkan</h5>
                    <img src="<?php echo e(asset('backend/img/4042.png')); ?>" alt="404 Not Found!">
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 d-flex justify-content-center">
            <div class="card" style="width: 70%;">
                <img src="<?php echo e(asset('uploads/'. $info->gambar)); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($info->judul); ?></h5>
                  <h6><i class="bi bi-tag-fill text-warning"></i> <?php echo e($info->kategori); ?> by <?php echo e($info->user->name); ?></h6>
                  <p class="card-text"><?php echo e($info->isi); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div> 
<?php elseif($message = Session::get('error')): ?>
<div class="alert alert-danger" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\efron\Workspace\Iconmedia\ppdb\resources\views/backend/informasi.blade.php ENDPATH**/ ?>