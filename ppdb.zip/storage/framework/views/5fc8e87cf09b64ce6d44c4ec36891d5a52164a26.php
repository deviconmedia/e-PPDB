<style>
    #pengumuman{
        margin-top: 8em;
    }
</style>

<?php $__env->startSection('title'); ?>
    Pengumuman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('studi'); ?>
   <div class="container d-block justify-content-center" id="pengumuman">
        <div class="row">
            <?php if($informasi->isEmpty()): ?>
                <div class="container d-flex justify-content-center">
                    <img src="<?php echo e(asset('frontend/img/empty.svg')); ?>" alt="404">
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(asset('uploads/'. $info->gambar)); ?>" class="card-img-top" alt="Informasi">
                        <div class="card-body">
                        <h5 class="card-title text-center"><?php echo e($info->judul); ?></h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="<?php echo e($info->slug); ?>" class="btn btn-primary">Selengkapnya</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>        
   </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/frontend/content/pengumuman.blade.php ENDPATH**/ ?>