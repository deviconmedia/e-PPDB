<?php $__env->startSection('title', 'Periode Baru'); ?>

<?php $__env->startSection('page-title', 'Periode Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="ibox">
    <div class="ibox-body">
        <form action="<?php echo e(route('admin.periode.store')); ?>" method="POST" class="needs-validation" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nama_periode">Nama Periode</label>
                <input type="text" class="form-control" id="nama_periode" name="nama_periode" placeholder="Cth: PPDB Gelombang I" required>
                    <div class="invalid-feedback">
                        Field wajib di isi!
                    </div>
              </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="tanggal_mulai">Tanggal Mulai</label>
                <input type="date" class="form-control" id="tanggal_mulai" name="tanggal_mulai" required>
                <div class="invalid-feedback">
                    Field wajib di isi!
                </div>
              </div>
              <div class="form-group col-md-6">
                <label for="tanggal_selesai">Tanggal Selesai</label>
                <input type="date" class="form-control" id="tanggal_selesai" name="tanggal_selesai" required>
                <div class="invalid-feedback">
                    Field wajib di isi!
                </div>
              </div>
            </div>
            <div class="form-group">
                <label for="ket">Keterangan</label>
                <textarea class="form-control" name="ket" id="ket" cols="30" rows="4" required></textarea>
                <div class="invalid-feedback">
                    Field wajib di isi!
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </form>
    </div>
</div>

<script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
      }, false);
    })();
    </script>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div> 
<?php elseif($message = Session::get('error')): ?>
<div class="alert alert-danger" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div>
<?php endif; ?>
<div class="alert alert-warning" role="alert">
  <h4 class="alert-heading">Perhatian!</h4>
  <p>Menjadwalkan periode baru akan menutup peride yang sedang berjalan saat ini.</p>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/admin/periode/create.blade.php ENDPATH**/ ?>