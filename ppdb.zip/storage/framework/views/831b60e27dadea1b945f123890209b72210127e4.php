   
 <div class="container">
        <h1 class="about-title">Program Studi</h1>
        <p class="about-sub-title">Kami menyediakan beberapa jurusan, pilih Passion kamu!</p>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-duration="2s" data-wow-delay=".1s">
                <div class="service-box2">
                    <div class="service-box-icon">
                        <a href="#"><i class="fa fa-book" aria-hidden="true"></i></a>
                    </div>
                    <h3><a href="#">Teknik Komputer & Jaringan</a></h3>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-duration="2s" data-wow-delay=".4s">
                <div class="service-box2">
                    <div class="service-box-icon">
                        <a href="#"><i class="fa fa-book" aria-hidden="true"></i></a>
                    </div>
                    <h3><a href="#">Teknik Jaringan Akses Telekomunikasi</a></h3>
                    
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-duration="2s" data-wow-delay=".7s">
                <div class="service-box2">
                    <div class="service-box-icon">
                        <a href="#"><i class="fa fa-book" aria-hidden="true"></i></a>
                    </div>
                    <h3><a href="#">Multimedia</a></h3>
                   
                </div>
            </div>
            
        </div>
    </div><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/frontend/studi.blade.php ENDPATH**/ ?>