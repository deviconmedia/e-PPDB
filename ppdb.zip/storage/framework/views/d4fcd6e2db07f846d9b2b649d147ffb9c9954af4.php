<?php $__env->startSection('title', 'Riwayat Pendaftaran'); ?>

<?php $__env->startSection('page-title', 'Riwayat Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="ibox">
        <div class="ibox-body text-center">
            <?php if($pendaftaran == null): ?>
                <div class="alert alert-warning">Anda belum memiliki riwayat pendaftaran!</div>
                <img src="<?php echo e(asset('backend/img/4042.png')); ?>" alt="404 Not Found!">
            <?php else: ?>
                <table class="table table-bordered">
                    <tr class="bg-secondary">
                        <th>DATA DIRI PENDAFTAR</th>
                        <td class="bg-secondary"></td>
                    </tr>
                    <tr>
                        <th>No Pendaftaran</th>
                        <td class="text-left"><?php echo e($pendaftaran->no_pendaftaran); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Lengkap</th>
                        <td class="text-left"><?php echo e($pendaftaran->nama_lengkap); ?></td>
                    </tr>
                    <tr>
                        <th>NISN</th>
                        <td class="text-left"><?php echo e($pendaftaran->nisn); ?></td>
                    <tr>
                    <tr>
                        <th>NIK</th>
                        <td class="text-left"><?php echo e($pendaftaran->nik); ?></td>
                    </tr>
                    <th>Tempat, Tanggal Lahir</th>
                    <td class="text-left">
                        <?php echo e($pendaftaran->tempat_lahir); ?>, <?php echo e($pendaftaran->tanggal_lahir); ?>

                    </td>
                    </tr>
                    <tr>
                        <th>Jenis Kelamin</th>
                        <td class="text-left"><?php echo e($pendaftaran->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                        <th>Agama</th>
                        <td class="text-left"><?php echo e($pendaftaran->agama); ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td class="text-left"><?php echo e($pendaftaran->alamat); ?></td>
                    </tr>
                    <tr>
                        <th>No. HP</th>
                        <td class="text-left"><?php echo e($pendaftaran->no_hp); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td class="text-left"><?php echo e($pendaftaran->email); ?></td>
                    </tr>
                    <tr class="bg-secondary">
                        <th>DATA ORANGTUA/WALI</th>
                        <td class="bg-secondary"></td>
                    </tr>
                    <tr>
                        <th>Nama Ayah</th>
                        <td class="text-left"><?php echo e($dataOrangTua->nama_ayah); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Ibu</th>
                        <td class="text-left"><?php echo e($dataOrangTua->nama_ibu); ?></td>
                    </tr>
                    <tr>
                        <th>Pekerjaan Ayah</th>
                        <td class="text-left"><?php echo e($dataOrangTua->pekerjaan_ayah); ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td class="text-left"><?php echo e($dataOrangTua->alamat); ?></td>
                    </tr>
                    <tr>
                        <th>No. HP</th>
                        <td class="text-left"><?php echo e($dataOrangTua->no_hp); ?></td>
                    </tr>
                    <tr class="bg-secondary">
                        <th>DATA SEKOLAH ASAL</th>
                        <td class="bg-secondary"></td>
                    </tr>
                    <tr>
                        <th>Nama Sekolah Asal</th>
                        <td class="text-left"><?php echo e($dataSekolah->nama_sekolah); ?></td>
                    </tr>
                    <tr>
                        <th>Tahun Lulus</th>
                        <td class="text-left"><?php echo e($dataSekolah->tahun_lulus); ?></td>
                    </tr>
                    <tr>
                        <th>No. Ijazah</th>
                        <td class="text-left"><?php echo e($dataSekolah->no_ijazah); ?></td>
                    </tr>
                    <tr>
                        <th>Status Pendaftaran</th>
                        <td class="text-left">
                            <?php if($pendaftaran->status_id == 1): ?>
                                <span class="badge badge-warning">
                                    <?php echo e($pendaftaran->status_pendaftaran->status); ?>

                                </span>
                            <?php elseif($pendaftaran->status_id == 2): ?>
                                <span class="badge badge-success">
                                    <?php echo e($pendaftaran->status_pendaftaran->status); ?>

                                </span>
                            <?php elseif($pendaftaran->status_id == 3): ?>
                                <span class="badge badge-danger">
                                    <?php echo e($pendaftaran->status_pendaftaran->status); ?>

                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            <?php endif; ?>
        </div>
    </div>

    
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" role="alert">
            <div class="alert-body">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="close" data-dismiss="alert">×</button>
            </div>
        </div> 
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/guest/pendaftaran/riwayat.blade.php ENDPATH**/ ?>