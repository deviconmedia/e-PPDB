<header class="header">
    <div class="page-brand">
        <a class="link" href="index.html">
            <span class="brand">Icon
                <span class="brand-tip">Media</span>
            </span>
            <span class="brand-mini">IM</span>
        </a>
    </div>
    <div class="flexbox flex-1">
        <!-- START TOP-LEFT TOOLBAR-->
        <ul class="nav navbar-toolbar">
            <li>
                <a class="nav-link sidebar-toggler js-sidebar-toggler"><i class="ti-menu"></i></a>
            </li>
            <li>
                <a href="<?php echo e(route('ppdb.index')); ?>" target="_blank" class="nav-link sidebar-toggler js-sidebar-toggler"><i class="bi bi-globe"></i></a>
            </li>
            
        </ul>
        <!-- END TOP-LEFT TOOLBAR-->
        <!-- START TOP-RIGHT TOOLBAR-->
        <ul class="nav navbar-toolbar">
            
            <li class="dropdown dropdown-user">
                <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                    <img src="<?php echo e(asset('backend/img/admin-avatar.png')); ?>" />
                    <span></span><?php echo e(Auth()->user()->name); ?><i class="fa fa-angle-down m-l-5"></i></a>
                <ul class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="<?php echo e(route('admin.profile.index')); ?>"><i class="fa fa-user"></i>Profile</a>
                    <a class="dropdown-item" href="<?php echo e(route('website.setting.index')); ?>"><i class="fa fa-cog"></i>Settings</a>
                    <li class="dropdown-divider"></li>
                    <a class="dropdown-item" href="<?php echo e(route('auth.logout')); ?>" onclick="return confirm('Anda yakin untuk keluar?')"><i class="fa fa-power-off"></i>Logout</a>
                </ul>
            </li>
        </ul>
        <!-- END TOP-RIGHT TOOLBAR-->
    </div>
</header><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/layouts/backend/header.blade.php ENDPATH**/ ?>