<style>
    .programs{
        margin-top: 8em;
    }
</style>

<?php $__env->startSection('title'); ?>
    Program Studi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('studi'); ?>
    <div class="programs">
        
       <div class="container d-flex justify-content-center">
        <h2 class="about-title">Program Studi</h2>
        <p class="about-sub-title">Kami menyediakan beberapa jurusan, pilih Passion kamu!</p>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeIn">
                <div class="card shadow-lg" style="width: 28rem;">
                    <img src="<?php echo e(asset('frontend/img/jurusan/1.jpg')); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h3 class="card-title text-center">Teknik Komputer & Jaringan</h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeIn">
                <div class="card shadow-lg" style="width: 28rem;">
                    <img src="<?php echo e(asset('frontend/img/jurusan/2.jpg')); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h3 class="card-title text-center">Teknik Jaringan Akses Telekomunikasi</h3>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeIn">
                <div class="card shadow-lg" style="width: 28rem;">
                    <img src="<?php echo e(asset('frontend/img/jurusan/3.jpg')); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h3 class="card-title text-center">Multimedia</h3>
                    </div>
                </div>
            </div>
        </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/frontend/content/program_studi.blade.php ENDPATH**/ ?>