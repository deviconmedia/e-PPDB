<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('page-title', 'Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
    <ul class="nav nav-pills nav-fill">
        <li class="nav-item">
        <h1><a class="nav-link bg-success" href="#card-index">1</a></h1>
        </li>
        <li class="nav-item">
        <h1><a class="nav-link bg-success" href="#">2</a></h1>
        </li>
        <li class="nav-item">
            <h1><a class="nav-link active" href="#">3</a></h1>
        </li>
        <li class="nav-item">
        <h1><a class="nav-link bg-secondary">4</a></h1>
        </li>
    </ul>
    <div class="card" id="card-second">
        <div class="card-header"><i class="bi bi-bank"></i> DATA SEKOLAH ASAL</div>
        <div class="card-body">
            <form action="<?php echo e(route('guest.pendaftaran.data-sekolah')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="nama_sekolah">Nama Sekolah Asal</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_sekolah" name="nama_sekolah" autofocus value="<?php echo e(old('nama_sekolah')); ?>">
                        <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>    
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="tahun_lulus">Tahun Lulus</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['tahun_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tahun_lulus" name="tahun_lulus" value="<?php echo e(old('tahun_lulus')); ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="no_ijazah">No Ijazah</label>
                        <input type="text" class="form-control" id="no_ijazah" name="no_ijazah">
                    </div>
                </div>
                <a href="" class="btn btn-danger">Tutup</a>
                <button type="submit" class="btn btn-success">Simpan dan lanjutkan</button>
            </form>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/guest/pendaftaran/data_sekolah.blade.php ENDPATH**/ ?>