<style>
    #alur{
        margin-top: 8em;
    }
</style>

<?php $__env->startSection('title'); ?>
    Berkas Pendaftaran
<?php $__env->stopSection(); ?>

<?php $__env->startSection('studi'); ?>
   <div class="container text-center" id="alur">
    <h2 class="text-center mb-3">Berkas Pendaftaran</h2>
    <img src="<?php echo e(asset('frontend/img/berkas.png')); ?>" alt="">
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/frontend/content/berkas.blade.php ENDPATH**/ ?>