<!-- GLOBAL MAINLY STYLES-->
<link href="<?php echo e(asset('backend/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('backend/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('backend/vendors/themify-icons/css/themify-icons.css')); ?>" rel="stylesheet" />
<!-- PLUGINS STYLES-->
<!-- THEME STYLES-->
<link href="<?php echo e(asset('backend/css/main.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
<!-- PAGE LEVEL STYLES-->
 <!-- PLUGINS STYLES-->
 <link href="<?php echo e(asset('backend/vendors/DataTables/datatables.min.css')); ?>" rel="stylesheet" />
 <link href="<?php echo e(asset('backend/vendors/summernote/dist/summernote.css')); ?>" rel="stylesheet" />
 <script src="http://code.jquery.com/jquery-2.2.1.min.js"></script><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/layouts/backend/style.blade.php ENDPATH**/ ?>