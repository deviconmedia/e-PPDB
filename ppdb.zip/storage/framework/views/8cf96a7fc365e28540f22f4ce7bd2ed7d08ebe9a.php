

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="ibox bg-success color-white widget-stat">
            <div class="ibox-body">
                <h2 class="m-b-5 font-strong"><?php echo e($totalSiswa); ?></h2>
                <div class="m-b-5">TOTAL SISWA</div><i class="bi bi-mortarboard-fill widget-stat-icon"></i>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="ibox bg-info color-white widget-stat">
            <div class="ibox-body">
                <h2 class="m-b-5 font-strong"><?php echo e($totalPendaftaran); ?></h2>
                <div class="m-b-5">TOTAL PENDAFTARAN</div><i class="bi bi-person-plus-fill widget-stat-icon"></i>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="ibox bg-warning color-white widget-stat">
            <div class="ibox-body">
                <h2 class="m-b-5 font-strong"><?php echo e($totalStaff); ?></h2>
                <div class="m-b-5">TOTAL STAFF</div><i class="bi bi-person-vcard-fill widget-stat-icon"></i>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="ibox bg-danger color-white widget-stat">
            <div class="ibox-body">
                <h2 class="m-b-5 font-strong"><?php echo e($totalUsers); ?></h2>
                <div class="m-b-5">TOTAL USERS</div><i class="ti-user widget-stat-icon"></i>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\efron\Workspace\Iconmedia\ppdb\resources\views/backend/admin/index.blade.php ENDPATH**/ ?>