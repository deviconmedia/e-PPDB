<?php $__env->startSection('title', 'Data Pendaftaran'); ?>

<?php $__env->startSection('page-title', 'Data Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="ibox">
    <div class="ibox-head">
        <div class="ibox-title">Data Pendaftaran</div>
    </div>
    <div class="ibox-body">
        <table class="table table-striped table-bordered table-hover table-responsive" id="example-table" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Aksi</th>
                    <th>No Pendaftaran</th>
                    <th>Nama Lengkap</th>
                    <th>NISN</th>
                    <th>TTL</th>
                    <th>Jenis Kelamin</th>
                    <th>Agama</th>
                    <th>Tahun Lulus</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <tr>
                    <td>
                        <a href="<?php echo e(route('admin.pendaftaran.show', $item->id)); ?>" class="btn btn-sm btn-primary mr-2">
                            <i class="fa fa-eye"></i>
                        </a>
                        
                        <form action="<?php echo e(route('admin.pendaftaran.destroy', $item->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Anda yakin menghapus data ini? klik BATAL jika anda tidak yakin!')">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                    </td>
                    <td><?php echo e($item->no_pendaftaran); ?></td>
                    <td><?php echo e($item->nama_lengkap); ?></td>
                    <td><?php echo e($item->nisn); ?></td>
                    <td><?php echo e($item->tempat_lahir); ?>, <?php echo e($item->tanggal_lahir); ?></td>
                    <td><?php echo e($item->jenis_kelamin); ?></td>
                    <td><?php echo e($item->agama); ?></td>
                    <td><?php echo e($item->tahun_lulus); ?></td>
                    <td>
                        <?php if($item->status_id == 1): ?>
                            <span class="badge badge-warning">
                                <?php echo e($item->status_pendaftaran->status); ?>

                            </span>
                        <?php elseif($item->status_id == 2): ?>
                            <span class="badge badge-success">
                                <?php echo e($item->status_pendaftaran->status); ?>

                            </span>
                        <?php elseif($item->status_id == 3): ?>
                            <span class="badge badge-danger">
                                <?php echo e($item->status_pendaftaran->status); ?>

                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

 
 <?php if($message = Session::get('success')): ?>
 <div class="alert alert-success" role="alert">
     <div class="alert-body">
         <strong><?php echo e($message); ?></strong>
         <button type="button" class="close" data-dismiss="alert">×</button>
     </div>
 </div> 
<?php elseif($message = Session::get('error')): ?>
 <div class="alert alert-danger" role="alert">
     <div class="alert-body">
         <strong><?php echo e($message); ?></strong>
         <button type="button" class="close" data-dismiss="alert">×</button>
     </div>
 </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/admin/pendaftaran.blade.php ENDPATH**/ ?>