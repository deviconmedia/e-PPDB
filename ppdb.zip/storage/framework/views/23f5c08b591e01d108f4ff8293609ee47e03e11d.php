<nav class="page-sidebar" id="sidebar">
    <div id="sidebar-collapse">
        <div class="admin-block d-flex">
            <div>
                <img src="<?php echo e(asset('backend/img/admin-avatar.png')); ?>" width="45px" />
            </div>
            <div class="admin-info">
                <div class="font-strong"><?php echo e(Auth()->user()->name); ?></div><small><?php echo e(Auth()->user()->role); ?></small></div>
        </div>
        <ul class="side-menu metismenu">
            
            <?php if(Auth::user()->role === 'admin'): ?>
            <li class="<?php echo e((request()->is('admin/home')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.index')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">Dashboard</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('admin/jurusan')) || (request()->is('admin/edit-jurusan/')) || (request()->is('admin/periode')) || (request()->is('admin/periode/create')) ? 'active' : ''); ?>">
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-cogs"></i>
                    <span class="nav-label">Master</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse">
                    <li>
                        <a href="<?php echo e(route('admin.jurusan.index')); ?>" class="<?php echo e((request()->is('admin/jurusan')) ? 'active' : ''); ?>">Jurusan</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.periode.index')); ?>" class="<?php echo e((request()->is('admin/periode')) || (request()->is('admin/periode/create')) ? 'active' : ''); ?>">Periode</a>
                    </li>
                </ul>
            </li>
            <li class="<?php echo e((request()->is('admin/data-pendaftaran')) || (request()->is('admin/detail-pendaftaran')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.pendaftaran.index')); ?>"><i class="sidebar-item-icon fa fa-users"></i>
                    <span class="nav-label">Data Pendaftaran</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('admin/data-siswa'))? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.siswa.index')); ?>"><i class="sidebar-item-icon bi bi-mortarboard-fill"></i>
                    <span class="nav-label">Data Siswa</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('admin/staff')) || (request()->is('informasi')) || (request()->is('new-informasi')) || (request()->is('admin/profile')) || (request()->is('admin/web-setting')) ? 'active' : ''); ?>">
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-cog"></i>
                    <span class="nav-label">Setup</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse">
                    <li>
                        <a href="<?php echo e(route('admin.staff.index')); ?>" class="<?php echo e((request()->is('admin/staff')) ? 'active' : ''); ?>">Staff</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('informasi.index')); ?>"  class="<?php echo e((request()->is('informasi')) || (request()->is('new-informasi')) ? 'active' : ''); ?>">Informasi</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.profile.index')); ?>"  class="<?php echo e((request()->is('admin/profile')) ? 'active' : ''); ?>">Profile</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('website.setting.index')); ?>"  class="<?php echo e((request()->is('admin/web-setting')) ? 'active' : ''); ?>">Website</a>
                    </li>
                </ul>
            </li>

            
            <?php elseif(Auth::user()->role == 'guest'): ?>
            <li class="<?php echo e((request()->is('guest/home')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('guest.index')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">Dashboard</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('guest/pendaftaran')) || (request()->is('guest/pendaftaran/data-orangtua')) || (request()->is('guest/pendaftaran/data-sekolah')) || (request()->is('guest/pendaftaran/berkas')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('guest.pendaftaran.index')); ?>"><i class="sidebar-item-icon fa fa-calendar"></i>
                    <span class="nav-label">Pendaftaran</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('guest/pendaftaran/riwayat'))? 'active' : ''); ?>">
                <a href="<?php echo e(route('guest.pendaftaran.riwayat')); ?>"><i class="sidebar-item-icon fa fa-calendar"></i>
                    <span class="nav-label">Riwayat Pendaftaran</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('informasi')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('informasi.index')); ?>"><i class="sidebar-item-icon bi bi-megaphone"></i>
                    <span class="nav-label">Informasi</span>
                </a>
            </li>
            
            <?php elseif(Auth::user()->role == 'siswa'): ?>
            <li class="<?php echo e((request()->is('siswa/home')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('siswa.index')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">Dashboard</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('siswa/pembayaran')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('pembayaran.index')); ?>"><i class="sidebar-item-icon bi bi-cash"></i>
                    <span class="nav-label">Pembayaran</span>
                </a>
            </li>
            <li class="<?php echo e((request()->is('informasi')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('informasi.index')); ?>"><i class="sidebar-item-icon bi bi-megaphone"></i>
                    <span class="nav-label">Informasi</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/layouts/backend/sidebar.blade.php ENDPATH**/ ?>