

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="ibox bg-primary color-white widget-stat">
            <div class="ibox-body">
                <h2 class="m-b-5 font-strong">Hi, <?php echo e(Auth::user()->name); ?></h2>
                <div class="m-b-5">Selamat datang di aplikasi PPDB Online</div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\efron\Workspace\Iconmedia\ppdb\resources\views/backend/guest/index.blade.php ENDPATH**/ ?>