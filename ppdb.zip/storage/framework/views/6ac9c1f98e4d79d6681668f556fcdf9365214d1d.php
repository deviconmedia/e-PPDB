<header>
    <div id="header1" class="header1-area">
        <div class="main-menu-area bg-primary" id="sticker">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-3">
                        <div class="logo-area">
                             <a href="<?php echo e(route('ppdb.index')); ?>"><img class="img-responsive" src="<?php echo e(asset('frontend/img/ifiber.png')); ?>" alt="logo"></a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-9">
                        <nav id="desktop-nav">
                            <ul>
                                <li><a href="<?php echo e(route('ppdb.program.studi')); ?>" class="<?php echo e((request()->is('program-studi')) ? 'active' : ''); ?>">Program Studi</a></li>
                                <li><a href="<?php echo e(route('ppdb.alur.pendaftaran')); ?>" class="<?php echo e((request()->is('alur-pendaftaran')) ? 'active' : ''); ?>">Alur Pendaftaran</a></li>
                                <li><a href="<?php echo e(route('ppdb.pengumuman')); ?>" class="<?php echo e((request()->is('pengumuman')) ? 'active' : ''); ?>">Pengumuman</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-lg-4 col-md-4 hidden-sm">
                        <div class="apply-btn-area">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <a href="<?php echo e(route('admin.index')); ?>" class="apply-now-btn3">Home</a>
                                <?php elseif(Auth::user()->role == 'siswa'): ?>
                                    <a href="<?php echo e(route('siswa.index')); ?>" class="apply-now-btn3">Home</a>
                                <?php elseif(Auth::user()->role == 'guest'): ?>
                                    <a href="<?php echo e(route('guest.index')); ?>" class="apply-now-btn3">Home</a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('auth.login')); ?>" class="apply-now-btn3">Login</a>
                                <a href="<?php echo e(route('auth.register')); ?>" class="apply-now-btn">Daftar</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu Area Start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul>
                                <ul>
                                    <li><a href="#">Program Studi</a></li>
                                    <li><a href="#">Alur Pendaftaran</a></li>
                                    <li><a href="#">Berkas</a></li>
                                    <li><a href="#">Biaya</a></li>
                                </ul>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu Area End -->
</header><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/layouts/frontend/header.blade.php ENDPATH**/ ?>