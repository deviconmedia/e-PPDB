<?php $__env->startSection('title', 'Staff'); ?>

<?php $__env->startSection('page-title', 'Staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-3 col-md-4">
        <div class="ibox">
            <div class="ibox-body text-center">
                <div class="m-t-20">
                    
                </div>
                <h5 class="font-strong m-b-10 m-t-10"><?php echo e($staff->nama); ?></h5>
                <div class="m-b-20 text-muted"><?php echo e($staff->email); ?></div>
                <div class="profile-social m-b-20">
                    <a href="javascript:;"><i class="fa fa-twitter"></i></a>
                    <a href="javascript:;"><i class="fa fa-facebook"></i></a>
                    <a href="javascript:;"><i class="fa fa-pinterest"></i></a>
                    <a href="javascript:;"><i class="fa fa-dribbble"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-9 col-md-8">
        <div class="ibox">
            <div class="ibox-body">
                <ul class="nav nav-tabs tabs-line">
                    <li class="nav-item">
                        <a class="nav-link active" href="#tab-1" data-toggle="tab"><i class="ti-bar-chart"></i> Overview</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#tab-2" data-toggle="tab"><i class="bi bi-pencil"></i> Edit</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#tab-3" data-toggle="tab"><i class="ti-announcement"></i> Feeds</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="tab-1">
                        <div class="row">
                            <div class="col-md-6" style="border-right: 1px solid #eee;">
                                <h5 class="text-info m-b-20 m-t-10"><i class="fa fa-user"></i> Biodata</h5>
                                <div class="m-b-20">
                                    <form action="">
                                        <div class="form-group">
                                            <label for="">Name</label>
                                            <input type="text" value="<?php echo e($staff->nama); ?>" class="form-control" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Email</label>
                                            <input type="text" value="<?php echo e($staff->email); ?>" class="form-control" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Tanggal Gabung</label>
                                            <input type="text" value="<?php echo e(date('d F Y, H:i:s', strtotime($staff->created_at))); ?>" class="form-control" readonly>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                        </div>
                        
                        
                    </div>
                    <div class="tab-pane fade" id="tab-2">
                        <form action="<?php echo e(route('admin.staff.update', $staff->id)); ?>" method="POST" id="staffUpdateForm">
                            
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label>Name</label>
                                <input class="form-control" type="text" name="nama" value="<?php echo e($staff->nama); ?>" >
                            </div>
                            <div class="form-group">
                                <label>Email Address</label>
                                <input class="form-control" type="email" name="email" value="<?php echo e($staff->email); ?>" >
                            </div>
                            <div class="form-group">
                                <label>New Password</label>
                                <input class="form-control" type="password" name="newPass" id="newPass">
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input class="form-control" type="password" name="newPassConf">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="tab-3">
                        <h5 class="text-info m-b-20 m-t-20"><i class="fa fa-bullhorn"></i> Latest Feeds</h5>
                        <ul class="media-list media-list-divider m-0">
                            <li class="media">
                                <div class="media-img"><i class="ti-user font-18 text-muted"></i></div>
                                <div class="media-body">
                                    <div class="media-heading">New customer <small class="float-right text-muted">12:05</small></div>
                                    <div class="font-13">Lorem Ipsum is simply dummy text.</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-img"><i class="ti-info-alt font-18 text-muted"></i></div>
                                <div class="media-body">
                                    <div class="media-heading text-warning">Server Warning <small class="float-right text-muted">12:05</small></div>
                                    <div class="font-13">Lorem Ipsum is simply dummy text.</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-img"><i class="ti-announcement font-18 text-muted"></i></div>
                                <div class="media-body">
                                    <div class="media-heading">7 new feedback <small class="float-right text-muted">Today</small></div>
                                    <div class="font-13">Lorem Ipsum is simply dummy text.</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-img"><i class="ti-check font-18 text-muted"></i></div>
                                <div class="media-body">
                                    <div class="media-heading text-success">Issue fixed <small class="float-right text-muted">12:05</small></div>
                                    <div class="font-13">Lorem Ipsum is simply dummy text.</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-img"><i class="ti-shopping-cart font-18 text-muted"></i></div>
                                <div class="media-body">
                                    <div class="media-heading">7 New orders <small class="float-right text-muted">12:05</small></div>
                                    <div class="font-13">Lorem Ipsum is simply dummy text.</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-img"><i class="ti-reload font-18 text-muted"></i></div>
                                <div class="media-body">
                                    <div class="media-heading text-danger">Server warning <small class="float-right text-muted">12:05</small></div>
                                    <div class="font-13">Lorem Ipsum is simply dummy text.</div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .profile-social a {
        font-size: 16px;
        margin: 0 10px;
        color: #999;
    }

    .profile-social a:hover {
        color: #485b6f;
    }

    .profile-stat-count {
        font-size: 22px
    }
</style>

<script type="text/javascript">
    $(function() {
        $('#staffUpdateForm').validate({
            errorClass: "help-block",
            rules: {
                nama: {
                    required: true,
                },
                email: {
                    required: true,
                    email: true
                },
                newPass: {
                    required: true
                },
                newPassConf: {
                    required: true,
                    equalTo: "#newPass"
                }

            },
            highlight: function(e) {
                $(e).closest(".form-group").addClass("has-error")
            },
            unhighlight: function(e) {
                $(e).closest(".form-group").removeClass("has-error")
            },
        });
    });
</script>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div> 
<?php elseif($message = Session::get('error')): ?>
<div class="alert alert-danger" role="alert">
    <div class="alert-body">
        <strong><?php echo e($message); ?></strong>
        <button type="button" class="close" data-dismiss="alert">×</button>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/backend/admin/show_staff.blade.php ENDPATH**/ ?>