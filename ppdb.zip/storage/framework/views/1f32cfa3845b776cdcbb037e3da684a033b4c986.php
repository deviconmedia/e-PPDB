<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="<?php echo e(asset('backend/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('backend/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('backend/vendors/themify-icons/css/themify-icons.css')); ?>" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="<?php echo e(asset('backend/css/main.min.css')); ?>" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
</head>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <!-- START HEADER-->
        <?php echo $__env->make('layouts.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END HEADER-->
        <!-- START SIDEBAR-->
        <?php echo $__env->make('layouts.backend.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR-->
        <div class="content-wrapper">
            <!-- START PAGE CONTENT-->
            <div class="page-heading">
                
                <?php echo $__env->yieldContent('page-heading'); ?>
            </div>
            <div class="page-content fade-in-up">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- END PAGE CONTENT-->
            <?php echo $__env->make('layouts.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <!-- BEGIN THEME CONFIG PANEL-->
    
    <!-- END THEME CONFIG PANEL-->
    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    <!-- END PAGA BACKDROPS-->
    <!-- CORE PLUGINS-->
    <script src="<?php echo e(asset('backend/vendors/jquery/dist/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('backend/vendors/popper.js/dist/umd/popper.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('backend/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('backend/vendors/metisMenu/dist/metisMenu.min.js')); ?>vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="<?php echo e(asset('backend/vendors/jquery-slimscroll/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <!-- CORE SCRIPTS-->
    <script src="<?php echo e(asset('backend/js/app.min.js')); ?>" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
</body>

</html><?php /**PATH /home/admin22/Workspace/iconmedia/ppdb/resources/views/layouts/backend/master.blade.php ENDPATH**/ ?>